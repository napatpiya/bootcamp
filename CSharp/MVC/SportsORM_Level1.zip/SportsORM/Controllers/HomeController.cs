﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using SportsORM.Models;
using Microsoft.EntityFrameworkCore;

namespace SportsORM.Controllers
{
    public class HomeController : Controller
    {

        private static Context context;

        public HomeController(Context DBContext)
        {
            context = DBContext;
        }

        [HttpGet("")]
        public IActionResult Index()
        {
            ViewBag.BaseballLeagues = context.Leagues
                .Where(l => l.Sport.Contains("Baseball"));
            return View();
        }

        [HttpGet("level_1")]
        public IActionResult Level1()
        {
            // Leagues
            ViewBag.WomenLeagues = context.Leagues.Where( l => l.Name.Contains("Womens"));
            ViewBag.TypeOfHockey = context.Leagues.Where( type => type.Sport.Contains("Hockey"));
            ViewBag.NoFootball = context.Leagues.Where( type => !type.Sport.Contains("Football"));
            ViewBag.ConferencesLeagues = context.Leagues.Where( l => l.Name.Contains("Conference"));
            ViewBag.AtlanticRegion = context.Leagues.Where( l => l.Name.Contains("Atlantic"));

            // Teams
            ViewBag.DallasLocation = context.Teams.Where( t => t.Location.Contains("Dallas"));
            ViewBag.NamedRapters = context.Teams.Where( t => t.TeamName.Contains("Raptors"));
            ViewBag.IncludeCity = context.Teams.Where( t => t.Location.Contains("City"));
            ViewBag.NameStartT = context.Teams.Where( t => t.TeamName.StartsWith("T"));
            ViewBag.OrderbyLocation = context.Teams.OrderBy( t => t.Location);
            ViewBag.OrderbyName = context.Teams.OrderByDescending( t => t.TeamName);

            // Players
            ViewBag.LastnameCooper = context.Players.Where( t => t.LastName.Contains("Cooper"));
            ViewBag.FirstnameJoshua = context.Players.Where( t => t.FirstName.Contains("Joshua"));
            ViewBag.LastNameCooperNoJoshua = context.Players.Where( t => t.LastName.Contains("Cooper")).Where( t => !t.FirstName.Contains("Joshua"));
            ViewBag.FirstnameAlexanderAndWyatt = context.Players.Where( t => t.FirstName.Contains("Alexander") || t.FirstName.Contains("Wyatt")).OrderBy( t => t.FirstName );

            return View();
        }

        [HttpGet("level_2")]
        public IActionResult Level2()
        {
            // Team and Leagues
            // ViewBag.AllteamInAtlanicSoccer = context.Teams.Join(
            //         context.Leagues, 
            //         t => t.LeagueId, 
            //         l => l.LeagueId,
            //         (t ,l) => new { Team = t, League = l}
            //         .Where( tl => tl.League.Name.Contains("AtlanticSoccer")));

            return View();
        }

        [HttpGet("level_3")]
        public IActionResult Level3()
        {
            return View();
        }

    }
}